/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package comparararchivos;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
import java.io.*;
import java.util.*;

public class CompararArchivos {

    static String repositorio;
    static String archivoAFiltrar;
    static String resultado;
    static String ruta="C:\\ProyectoZips";
    public static void main(String[] args) throws IOException {
    
        if (args.length < 3) {
            repositorio = "ListadoRepositorio.txt";
            archivoAFiltrar = "ListadoSimple.txt";
            resultado = "ListadoNuevos.txt";
            System.out.println("""
                               USO:
                                java -jar archivojar.jar "ListadoRepositorio" "ListadoSimple" "ListadoNuevos"
                               
                               """);
        } else {
            repositorio = args[0];
            archivoAFiltrar = args[1];
            resultado = args[2];
        }
       File f=new File(repositorio);
       if(!f.exists()){
           f.createNewFile();
       }
               
        Set<String> conjuntoRepositorio = new HashSet<>();
        try (BufferedReader br = new BufferedReader(new FileReader(repositorio))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                conjuntoRepositorio.add(linea.toLowerCase());
            }
        }

        int numeroLineas;
        try (BufferedReader br = new BufferedReader(new FileReader(archivoAFiltrar)); BufferedWriter bw = new BufferedWriter(new FileWriter(resultado))) {
            String linea;
            numeroLineas = 0;
            while ((linea = br.readLine()) != null) {
                if (!conjuntoRepositorio.contains(linea.toLowerCase())) {
                    bw.write(linea);
                    bw.newLine();
                    numeroLineas++;
                }
            }
        }
        System.out.println("Quedan " + numeroLineas + " Ficheros zip");
    }
}
