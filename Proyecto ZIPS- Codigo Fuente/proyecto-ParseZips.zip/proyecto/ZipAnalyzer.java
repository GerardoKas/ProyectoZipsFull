package proyecto;

import java.io.*;
import java.util.*;
import org.sqlite.SQLiteException;
import static proyecto.FuncionesAgregado.*;

public class ZipAnalyzer {

//        System.out.println("Se espera un archivo llamado 'ListadoFullZips.txt' con los datos de los archivos");
//        System.out.println("Este archivo lo crea el bat: 'listar_zips_then_7zip.bat'");
    public static void analizarLineas(String archivo) throws IOException {
        int numFiles = 0;
        long id_ruta = 0, id_zip = 0, id_foranea_zip = 0;
        boolean existe_zip = false;

        String fpath_dir = null, fpath_nombre = null, fpath = null, ftype = null, fsize = null;

        try ( BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.startsWith("7-Zip")) {
                    numFiles++;
                }
                if (linea.startsWith("Path = ")) {
                    fpath = linea.substring(7);
                    fpath_dir = ExtraerRuta(fpath);
                    id_ruta = tabla_raiz_add(fpath_dir);
                }
                if (linea.startsWith("Physical Size = ")) {
                    fsize = linea.substring(16);
                    fpath_nombre = ExtraerNombre(fpath);
                    existe_zip = existe_zip_check(fpath_nombre);
                    if (!existe_zip) {
                        id_zip = tabla_zips_add(fpath_nombre, Long.parseLong(fsize), id_ruta);
                        System.out.println("ID_ZIP:" + fpath);
                        id_foranea_zip = id_zip;
                    }else{
                        System.out.println("ok.");
                    }
                }
                if (linea.matches("(\\d+) files, (\\d+)folders")) {
                    System.out.println("|");
                }
                
                if (linea.matches("\\d{4}-\\d{2}-\\d{2}\\s+\\d{2}:\\d{2}:\\d{2}\\s+[.\\w]+\\s+\\d+\\s+\\d+\\s{2}.+")) {
                    if (!existe_zip) {
                        String[] parts = linea.split("\\s+");
                        String atributos = parts[2];//"attr"+
                        if (atributos.indexOf("D") == -1) {
                            String fecha = parts[0] + " " + parts[1];//("fecha"+
                            long tamano = Long.parseLong(parts[3]);
                            String nombre = String.join(" ", Arrays.copyOfRange(parts, 5, parts.length));
                            String ext = getExtension(nombre);
                            String rutaInterna = ExtraerRuta(nombre);
                            String soloNombre = ExtraerNombre(nombre);
                            System.out.print(soloNombre+" - ");
                            Long id_contenido = tabla_contenido_add(soloNombre, rutaInterna, tamano, fecha, ext, id_foranea_zip);
                        }
                    } else {
                        //("Dir:"+linea);
                    }

                }
            }
        }

        System.out.println("Numero de archivos: " + numFiles);
    }

}
