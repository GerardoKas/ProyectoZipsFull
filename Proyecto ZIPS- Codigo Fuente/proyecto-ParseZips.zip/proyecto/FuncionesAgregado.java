package proyecto;



import java.sql.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class FuncionesAgregado {

    private static Connection con;
    public static long id_path;

    public static void setConexion(Connection con) {
        FuncionesAgregado.con = con;
    }

    //devuelve el id_path
    /**
     * 1. Las sentencias sql 2. Try alrededor de las consultas 3. Crea el
     * statement con la conexion con 4. Ejecuta consulta SELECT para saber si
     * existe el path y lo guarda en rs_id_path 5. Comprueba if si hay next() si
     * hay: asigna la primera columna de la consulta a id_path si no hay:
     * ejecuta el INSERT de ruta si afecta a alguna fila es que se añadio repite
     * el SELECT buscando id_ruta. avanza y obtiene el id_path en
     * rs_id_path.getLong(columna_1)
     *
     * @param path la ruta a agregar
     * @return el id_path
     */
    public static long tabla_raiz_add(String path) {
        String sql_select_path = "SELECT id_ruta from rutas WHERE ruta='" + path + "'";

        String sql_update_path = "INSERT INTO rutas (ruta) VALUES (\"" + path + "\")";

        try {
            Statement st = con.createStatement();

            //consultar si existe el elemento path
            ResultSet rs_id_path = st.executeQuery(sql_select_path);

            if (rs_id_path.next()) {
                //existe
                id_path = rs_id_path.getLong(1);
            } else {
                //si no existe el elemento Lo añadimos
                st = con.createStatement();
                int filasAfectadas = st.executeUpdate(sql_update_path);
                if (filasAfectadas == 1) {
                    //ok añadido
                    System.out.println("añadio");
                    rs_id_path = st.executeQuery(sql_select_path);
                    rs_id_path.next();
                    id_path = rs_id_path.getLong(1);
                } else {
                    //no se añadio
                    System.out.println("No añadio el elemento " + path);
                }

            }
            rs_id_path.close();
            st.close();
            //con.close();
        } catch (SQLException e) {
            System.out.println("errror");
            System.out.println(e.getMessage());
        }
        return id_path;

    }

    public static long tabla_zips_add(String zip_name, long zip_size, long id_foranea_ruta) {
        //id_foranea es el id_ruta
        String sql_select_zip = "SELECT id_zip FROM ficheros_zip WHERE id_foranea_ruta= ? AND zip_name= ?";
        String sql_insert_zip = "INSERT INTO ficheros_zip (zip_name,zip_size,id_foranea_ruta) VALUES (?,?, ?)";
        try {

            PreparedStatement prep_select = con.prepareStatement(sql_select_zip);
            prep_select.setLong(1, id_foranea_ruta);
            prep_select.setString(2, zip_name);
            ResultSet rs_select_zip = prep_select.executeQuery();

            if (rs_select_zip.next()) {
                //Si existe ese zip copia el id
                return rs_select_zip.getLong(1);
            } else {
                //no existe. Updatear
                PreparedStatement prep_update = con.prepareStatement(sql_insert_zip);
                prep_update.setString(1, zip_name);
                prep_update.setLong(2, zip_size);
                prep_update.setLong(3, id_foranea_ruta);
                //efectivo==1 si añadio un elemento
                int efectivo = prep_update.executeUpdate();
                if (efectivo == 1) {
                    rs_select_zip = prep_select.executeQuery();
                    if (rs_select_zip.next()) {
                        return rs_select_zip.getLong(1);
                    } else {
                        //no deberia ocurrir. despues de añadir
                        System.out.println("ERROR ESXTRAÑO ONO DE BERIA PAsAR");
                    }
                }
                prep_update.close();
                prep_select.close();
                rs_select_zip.close();

            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return 0;
    }

    public static long tabla_contenido_add(String nombre, String path, long tamano, String fecha, String extension, long id_foranea_zip) {
        PreparedStatement prep_update = null;
        PreparedStatement prep_select = null;
        String sql_select_detalle = "SELECT id_foranea_zip FROM contenidos WHERE nombre= ? AND path= ? and tamano=?";
        String sql_insert_detalle = "INSERT INTO contenidos (nombre,path,tamano,fecha,extension,id_foranea_zip) VALUES (?,?,?,?,?,?)";
        try {
            prep_select = con.prepareStatement(sql_select_detalle);
            prep_select.setString(1, nombre);
            prep_select.setString(2, path);
            prep_select.setLong(3, tamano);

            ResultSet rs_select_detalle = prep_select.executeQuery();

            if (rs_select_detalle.next() == false) {//PreparedStatement prep_update = null;
                prep_update = con.prepareStatement(sql_insert_detalle);
                prep_update.setString(1, nombre);
                prep_update.setString(2, path);
                prep_update.setLong(3, tamano);
                prep_update.setString(4, fecha);
                prep_update.setString(5, extension);
                prep_update.setLong(6, id_foranea_zip);
//                prep_update.setString(7, atributos);
                int efectivo = prep_update.executeUpdate();
                if (efectivo >= 1) {
                    //System.out.print("AAÑADIO-es nuevo");
                } else {
                    System.out.println("ERROR AL AÑADIR DETAALLLE");
                }
                prep_update.close();
                prep_select.close();
            } else {
                System.out.println("ya");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        return 0;
    }

    public static String ExtraerRuta(String filename) {
        String directorio = "";
        String regex = "^(.*)\\\\"; // Ajusta la barra invertida según tu sistema operativo

        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(filename);

        if (matcher.find()) {
            directorio = matcher.group(1);
        } else {
            directorio = "";
        }

        return directorio;
    }

    public static String ExtraerNombre(String filename) {
        int indice = filename.lastIndexOf("\\");
        String nombre = filename.substring(indice + 1);

        if (nombre != "") {
            return nombre;
        } else {
            System.out.println("No se ha podido extraer el nombre de la ruta");
        }
        return "";
    }

    public static String getExtension(String ruta) {
        int i = ruta.lastIndexOf(".");
        if (i == 0) {
            return "";
        }
        String extension = ruta.substring(i + 1);
        return extension;
    }

    public static boolean existe_zip_check(String nombreZip) {
        PreparedStatement prep_check;

        String sql_check_zip = "SELECT id_zip FROM ficheros_zip WHERE zip_name= ?";
        try {
            prep_check = con.prepareStatement(sql_check_zip);
            prep_check.setString(1, nombreZip);
            ResultSet rs_select_check = prep_check.executeQuery();

            return rs_select_check.next();
        
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return true;

    }
}
