/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class conexion {
  
    public static Connection con;
    
    public static Connection Conectar(String rutaDB) {
        System.out.println("INICIO");
        try {
            // Cargar el driver JDBC para MySQL
            //Class.forName("com.sqlite.jdbc.Driver");   
            Class.forName("org.sqlite.JDBC");

            // Establecer la conexión
            String url = "jdbc:sqlite:"+rutaDB;
            String user = "";
            String password = "";
            con = DriverManager.getConnection(url, user, password);

            // Si llegamos aquí, la conexión fue exitosa
            System.out.println("Conexión exitosa a la base de datos");

        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
        System.out.println("FINAL");
        return con;
    }
}