/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.io.IOException;
import java.sql.*;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
//System.out.println("Se espera un archivo llamado 'ListadoFullZips.txt' con los datos de los archivos");
//System.out.println("Este archivo lo crea el bat: 'listar_zips_then_7zip.bat'");
public class proyecto {

    private static String DATA_FILE = "c:\\ProyectoZips\\ListadoFullZips.txt";
    //private static final String LISTING_FILE = Paths.get("").toAbsolutePath().toString() + "/ListadoFullZips.txt";
    private static String database = "C:\\ProyectoZips\\DATAB.db";

    public static void main(String[] args) {
        if (args.length == 2) {
            //usa parametros
            DATA_FILE = args[0];
            System.out.println(DATA_FILE);
            database = args[1];
            System.out.println(database);
        } else {
            //no usa parametros
            System.out.println("Sin parametros se usaran los 2valores por defecto:\nListado:" + DATA_FILE + "\nBaseDeDatos:" + database);
        }
        Connection con = conexion.Conectar(database);
        FuncionesAgregado.setConexion(con);
        try {
            ZipAnalyzer.analizarLineas(DATA_FILE);
        } catch (IOException e) {
            System.out.println("ERROR AL ANALIZAR LINEAS:" + e.getMessage());
        }

    }
}
