package MyPack;

import java.io.IOException;
import java.sql.*;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class abreZips {

    private final String rutaExeFM = "\"C:\\Program Files\\7-Zip\\7zFM.exe\"";
    private final String rutaExe = "\"C:\\Program Files\\7-Zip\\7z.exe\"";
    private final String rutaEjecutar = "\"C:\\ProyectoZips\\dist\\Ejecutar.bat\"";
    private final String rutaTemporal = "C:\\TEMP\\Temporal_Java_Zips";
    private Controlador cont;

    public abreZips(Controlador cont) {
        this.cont = cont;
    }

    public int operarConZips(Rutas ruta, String comando) {
        System.out.println(ruta.getRutaInterna() + " : " + ruta.getRutaZip());
        String rutaInternaZip = ruta.getRutaInterna();
        String rutaCompletaZip = ruta.getRutaZip();
        int exitValue = 0;

        if (comando.isEmpty()) {
            comando = rutaExe + " x \"" + rutaCompletaZip + "\"  -o\"" + rutaTemporal + "\" \"" + rutaInternaZip + "\"";
            System.out.println("No ahbia comando: por defecto:");
        }
        System.out.println("COMANDO:" + comando);
        // Iniciar el proceso
        try {
            Process process = Runtime.getRuntime().exec(comando);
//            //Obtener la salida del comando
//            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
//            String line;
//            while ((line = reader.readLine()) != null) {
//                System.out.println(line);
//            }
            //exitValue = process.waitFor();
        } catch (IOException e) {
            System.out.println("El comando se ejecutó con salida: " + exitValue);
            System.out.println(e.getMessage());

        }
        //  abrirFicheroExtracto(rutaTemporal + "\\" + rutaInternaZip);
        return exitValue;

    }

    public void abrirFicheroExtracto(Rutas ruta) {
//        System.out.println("abriendo:"+rutaCompleta);
        String comando;

        comando = rutaExe + " x \"" + ruta.getRutaZip() + "\"  -o\"" + rutaTemporal + "\" \"" + ruta.getRutaInterna() + "\"";
        //comando="start "+"\""+ruta.getRutaTemporalCompleta()+"\"";

        operarConZips(ruta, comando);
//        comando = "cmd /c  cd \""+ruta.getRutaTemporalSimple()+"\" && start \""+ ruta.getNombreDetalle()+ "\"";
//
//        operarConZips(ruta, comando);

    }

    public void abrirEnNotepad(Rutas ruta) {
//        System.out.println("abriendo:"+rutaCompleta);
        String comando;
        comando = rutaExe + " x \"" + ruta.getRutaZip() + "\"  -o\"" + rutaTemporal + "\" \"" + ruta.getRutaInterna() + "\"";

        operarConZips(ruta, comando);

        comando = "notepad.exe \"" + ruta.getRutaTemporalCompleta() + "\"";
        //comando="start "+"\""+ruta.getRutaTemporalCompleta()+"\"";


        operarConZips(ruta, comando);

    }

    public void abrirCarpeta(Rutas ruta) {

        String comando = "explorer.exe \"" + ruta.getRutaCarpeta() + "\"";
        operarConZips(ruta, comando);

    }

    public void abrirSevenZip(Rutas ruta) {
        String comando = rutaExeFM + " \"" + ruta.getRutaZip() + "\"";
        operarConZips(ruta, comando);

    }

    public void abrirCarpetaTemporal(Rutas ruta) {
        String comando = "explorer.exe \"" + ruta.getRutaTemporalSimple() + "\"";
        operarConZips(ruta, comando);
    }

    public Rutas obtenerRegistroUnico(long datoIdZip) {
        String sql = """
                     SELECT contenidos.nombre, contenidos.path, ficheros_zip.zip_name, rutas.ruta 
                     FROM contenidos
                     INNER JOIN ficheros_zip ON contenidos.id_foranea_zip = ficheros_zip.id_zip
                     INNER JOIN rutas ON ficheros_zip.id_foranea_ruta=rutas.id_ruta
                     WHERE contenidos.id_detalle=""" + datoIdZip;
        String rutaInternaCompleta = "";
        String rutaZip = "";
        String nombre = "";
        String rutaTemporalCompleta = "";
        String rutaCarpeta = "";
        try {
            Connection con = cont.codegem.getCon();
            PreparedStatement prep = con.prepareStatement(sql);
//            prep.closeOnCompletion();
            ResultSet rs = prep.executeQuery();
            if (rs.next()) {
                nombre = rs.getString(1);
                String rutaInterna = rs.getString(2);
                String zipName = rs.getString(3);
                rutaCarpeta = rs.getString(4);
                rutaZip = rutaCarpeta + "\\" + zipName;
                rutaInternaCompleta = rutaInterna + "\\" + nombre;
                rutaTemporalCompleta = rutaTemporal + "\\" + rutaInternaCompleta;
                System.out.println("R_ZIP: " + rutaZip);
                System.out.println("R_INTERNA_COMP:" + rutaInternaCompleta);
                System.out.println("R_TEMP_COMPLETA:" + rutaTemporalCompleta);
            }
            rs.close();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return new Rutas(rutaZip, rutaCarpeta, rutaInternaCompleta, nombre, rutaTemporalCompleta);
    }
}
