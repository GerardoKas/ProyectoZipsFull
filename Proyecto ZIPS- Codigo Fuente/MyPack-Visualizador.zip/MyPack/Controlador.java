package MyPack;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class Controlador {
    public Codigo_Gemini_DB codegem;
    public Vista ventana;
    
    public Controlador() {
        
        ventana=new Vista(this);
        codegem=new Codigo_Gemini_DB(this);
        
        
    }

    
}
