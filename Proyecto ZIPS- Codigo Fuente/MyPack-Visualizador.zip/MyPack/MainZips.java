package MyPack;

import java.sql.SQLException;
import javax.swing.JFrame;

public class MainZips {

    /**
     * The main entry point of the application.
     * This method sets up the necessary components, connects to the database, and retrieves data from the database.
     * It then configures and displays the main window of the application.
     */
    public static void main(String[] args) {
        Controlador cont = new Controlador();
            cont.codegem.Conectar();

        try {
            cont.codegem.AgregaALaTabla(cont.codegem.consultaBasicaSQL);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
            // Configuraciones de la ventana
        cont.ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cierra la aplicación al cerrar la ventana
        cont.ventana.setLocationRelativeTo(null); // Centra la ventana en la pantalla
        cont.ventana.setVisible(true); // Hace visible la ventana

    }

}
