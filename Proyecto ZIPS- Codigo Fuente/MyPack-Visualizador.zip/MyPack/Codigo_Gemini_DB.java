package MyPack;

import javax.swing.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class Codigo_Gemini_DB {

    String where = "";
    String orden = "";

    String limit = " LIMIT 10000 ";
    String offsetPagina = " OFFSET 0";
    int numRegistrosTotal = 0;
    boolean ordenAscendente = true;
    public String consultaCompleta;
//         String sql = "select contenidos.* , ficheros_zip.zip_name from contenidos "
//                + "INNER JOIN ficheros_zip ON contenidos.id_foranea_zip = ficheros_zip.id_zip "
//                + where + orden + limit;
//         
         
    public final String consultaBasicaSQL = """
                                  SELECT contenidos.*,
                                         ficheros_zip.zip_name,
                                         rutas.ruta
                                    FROM contenidos
                                         INNER JOIN ficheros_zip ON contenidos.id_foranea_zip = ficheros_zip.id_zip
                                         INNER JOIN rutas ON ficheros_zip.id_foranea_ruta = rutas.id_ruta
                                         -- ORDER BY tamano DESC
                                         -- LIMIT 1000
                                         -- OFFSET 0
                                  """;
    private Connection con;
    private final JTable laTabla;
    private final Controlador cont;
    private final String bd = "C:\\ProyectoZips\\DATAB.db";

    public Connection getCon() {
        return con;
    }

    public Codigo_Gemini_DB(Controlador cont) {
        this.cont = cont;
        //this.con = Conectar();
        this.laTabla = cont.ventana.getjTable1();

    }

    public Connection Conectar() {
        if (con == null) {
            try {
                System.out.println("INICIO Conexion");
                // Cargar el driver JDBC
                Class.forName("org.sqlite.JDBC");
                String url = "jdbc:sqlite:" + bd;
                // Crear la conexión
                this.con = DriverManager.getConnection(url);
            } catch (ClassNotFoundException e) {
                System.out.println("Clasee no enccontrada\n" + e.getMessage());
                System.out.println("ERROR NULL EN CONEXION");
            } catch (SQLException e) {
                System.out.println("SQLExcepcion-ERROR SQL--- AL CONECTAR");
            }
        } else {
            System.out.println("YA ESTABA conectado:" + con.toString());
        }
        return con;
    }

    public String consultaNumRegistros_NOUSADO() {
        String consulta = "";
        int numPaginas = 0;
        try {
            consulta = consultaCompleta;
            //cuenta registros
            consulta = consulta.replace("SELECT", "SELECT COUNT(*) , ");
            PreparedStatement prepContar = con.prepareStatement(consulta);
            ResultSet rs = prepContar.executeQuery();
            if (rs.next()) {
                numRegistrosTotal = rs.getInt(1);
                System.out.println("NumElementos=" + numRegistrosTotal);
                numPaginas = numRegistrosTotal / 10000;
                cont.ventana.arreglaSlider(numPaginas);
            }
            offsetPagina = " OFFSET " + cont.ventana.getjSlider().getValue()*10000;
            System.out.println("offsetpagina:" + offsetPagina);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

        cont.ventana.getjLabelNumTotal().setText(numRegistrosTotal + " Num Total / " + numPaginas + " Paginas");
        System.out.println("consultaRegistros: " + consulta);
        return offsetPagina;
    }

    public void AgregaALaTabla(String consultaSql) throws SQLException {
// Suponiendo que tienes una conexión llamada con
        con = Conectar();
        consultaCompleta = consultaSql;

        System.out.println("COMPLETA:" + consultaCompleta);
        //contar numro deregistros con una consulta
      //offsetPagina = consultaNumRegistros();
        System.out.println("Esto aun no lo se: " + offsetPagina);
        PreparedStatement prep = con.prepareStatement(consultaCompleta);
        prep.closeOnCompletion();
        ResultSet rs = prep.executeQuery();

        // Crear un modelo de tabla
        DefaultTableModel model = new MiModeloTabla();//new DefaultTableModel();
        ResultSetMetaData metaData = rs.getMetaData();

        int columnCount = metaData.getColumnCount();

        // Agregar las columnas al modelo
        for (int i = 1; i <= columnCount; i++) {
            model.addColumn(metaData.getColumnName(i));
        }

        // Agregar los datos al modelo
        while (rs.next()) {
            Object[] row = new Object[columnCount];
            for (int i = 1; i <= columnCount; i++) {
                row[i - 1] = rs.getObject(i);
            }
            model.addRow(row);
        }
        laTabla.setModel(model);

        //contar numro deregistros con una consulta
        //consultaNumRegistros();

        modificarColumnas();

        celda_Tamano.cambiaTamanoKb(laTabla);

        cont.ventana.getLabelDetalles().setText(laTabla.getRowCount() + " Mostrados - " + " PAGINA" + offsetPagina);

    }

    private void modificarColumnas() {
        for (int i = 0; i < laTabla.getColumnCount(); i++) {

            TableColumn columna = laTabla.getColumnModel().getColumn(i);

            String nombre = columna.getHeaderValue().toString();
            switch (nombre) {
                case "tamano":
                    columna.setPreferredWidth(80);
                    columna.setMinWidth(100);
                    columna.setMaxWidth(100);
                    break;
                case "fecha":

                    columna.setPreferredWidth(130);
                    columna.setMinWidth(130);
                    columna.setMaxWidth(130);
                    break;
                case "extension":
                    columna.setPreferredWidth(1);
                    columna.setMinWidth(40);
                    columna.setMaxWidth(40);
                    break;
                case "id_detalle":
                    columna.setMinWidth(0);
                    columna.setMaxWidth(0);

                    break;
                case "id_foranea_zip":
                    columna.setMinWidth(0);
                    columna.setMaxWidth(0);
                    break;
                case "id_ruta":
                    columna.setMinWidth(0);
                    columna.setMaxWidth(0);
                    break;
                default:

            }
        }
        //laTabla.moveColumn(indiceColumnaActual, nuevoIndice);
        //laTabla.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
    }

    public String buscarTextoSQL(String cadenaBusqueda) {

        String select;

        //cadenaBusqueda = cadenaBusqueda.toLowerCase();
        concatenaCamposBusqueda(cadenaBusqueda);

        if (cadenaBusqueda.isEmpty()) {
            //select = "SELECT * FROM contenidos ";
            select = consultaBasicaSQL + orden + limit;
        } else {
            //select = "SELECT * FROM contenidos " + where;
            select = consultaBasicaSQL + where + orden + limit;
        }
        try {
            AgregaALaTabla(select);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        consultaCompleta = select;
        System.out.println("SELECT_BUSCA: " + select);
        return consultaCompleta;
    }

    public void concatenaCamposBusqueda(String cadenaBusqueda) {
        String andRuta = "";
        String andNombre = "";
        String andZip = "";
        if (cont.ventana.getjChkRutas().isSelected()) {
            andRuta = " LOWER(rutas.ruta) like LOWER('%" + cadenaBusqueda + "%') ";
        }
        if (cont.ventana.getjChkZips().isSelected()) {
            andZip = " LOWER(ficheros_zip.zip_name) like LOWER('%" + cadenaBusqueda + "%') ";
        }
        if (cont.ventana.getjChkNombres().isSelected()) {
            andNombre = " LOWER(contenidos.nombre) like LOWER('%" + cadenaBusqueda + "%') ";
        }

        StringBuilder cadena = new StringBuilder();

        if (!andNombre.isEmpty()) {
            cadena.append(andNombre);
        }
        if (!andRuta.isEmpty()) {
            if (cadena.length() > 0) {
                cadena.append(" OR ");
            }
            cadena.append(andRuta);
        }
        if (!andZip.isEmpty()) {
            if (cadena.length() > 0) {
                cadena.append(" OR ");
            }
            cadena.append(andZip);
        }

        if (!cadena.toString().isEmpty()) {
            where = " WHERE " + cadena.toString();
            System.out.println("WHERE:" + where);
        } else {
            where = "";
        }

    }

    public void consultaOrdenar(String nombreColumna) {

        if (ordenAscendente == true) {
            orden = " ORDER BY " + nombreColumna + " DESC ";
            ordenAscendente = false;
        } else {
            orden = " ORDER BY " + nombreColumna + " ASC ";
            ordenAscendente = true;
        }
        
        
        String sql = consultaBasicaSQL + where + orden + limit;
        try {
            cont.codegem.AgregaALaTabla(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        System.out.println("SELECT_ordenar:" + sql);

    }

}
