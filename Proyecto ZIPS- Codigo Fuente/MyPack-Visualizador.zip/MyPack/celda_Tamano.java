package MyPack;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class celda_Tamano {

    public static void cambiaTamanoKb(JTable tabla) {
        int indiceColumna = 2;

        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        for (int i = 0; i < modelo.getRowCount(); i++) {
            Object o = modelo.getValueAt(i, indiceColumna);
            long bytes = Long.parseLong(o.toString());
            double kb = (double) bytes / 1024;

            modelo.setValueAt(String.format("%,.2f KB", kb), i, indiceColumna);
        }
    }
}
