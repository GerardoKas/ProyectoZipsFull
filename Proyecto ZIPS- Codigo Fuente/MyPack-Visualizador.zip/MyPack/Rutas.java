package MyPack;

/**
 *
 * @author Gerardo.Castro.Mtz
 */
public class Rutas {
    private String rutaZip;
    private String rutaCarpeta;
    private String rutaInterna;

    private String nombreDetalle;
    private String rutaTemporalCompleta;
    private String rutaTemporalSimple;

    public String getRutaTemporalSimple() {
        return obtenerRutaSimple(rutaTemporalCompleta);
        
    }
    
//    public Rutas(String rutaZip, String rutaInterna) {
//        this.rutaZip = rutaZip;
//        this.rutaInterna = rutaInterna;
//        
//    }

    public Rutas(String rutaZip, String rutaCarpeta, String rutaInterna, String nombreDetalle, String rutaTemporalCompleta) {
        this.rutaZip = rutaZip;
        this.rutaCarpeta = rutaCarpeta;
        this.rutaInterna = rutaInterna;
        this.nombreDetalle = nombreDetalle;
        this.rutaTemporalCompleta = rutaTemporalCompleta;
    }

    
  
    
    public String getRutaCarpeta() {
        return rutaCarpeta;
    }
    
      
    public String getNombreDetalle() {
        return nombreDetalle;
    }

    public String getRutaTemporalCompleta() {
        return rutaTemporalCompleta;
    }
    

    public String getRutaZip() {
        return rutaZip;
    }

    public String getRutaInterna() {
        if (rutaInterna.indexOf("\\") == 0) {
            rutaInterna = rutaInterna.substring(1);
            System.out.println("La ruta interna es: " + rutaInterna);
        }
        return rutaInterna;
    }

    private String obtenerRutaSimple(String rutaCompleta) {
    // Buscamos la última aparición del separador de directorios
    int indiceUltimoSeparador = rutaCompleta.lastIndexOf("\\");
    // Si encontramos el separador, extraemos la ruta
    if (indiceUltimoSeparador != -1) {
        return rutaCompleta.substring(0, indiceUltimoSeparador + 1);
    } else {
        // Si no encontramos ningún separador, asumimos que la ruta es el mismo archivo
        return rutaCompleta;
    }
}
}
